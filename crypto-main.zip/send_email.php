<?php
require 'vendor/autoload.php'; // Path to PHPMailer autoloader

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                           
        $mail->Host       = 'smtp.gmail.com';                    
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'jennasurve@gmail.com';                     
        $mail->Password   = 'cwdsglijnbwuorhg';                               
        $mail->SMTPSecure = 'ssl';                                 
        $mail->Port       = 465;                                    

        //Recipients
        $mail->setFrom($email , $name);
        $mail->addAddress('diptisurve7415@gmail.com');                 

        // Content
        $mail->isHTML(true);                                       
        $mail->Subject = 'New Contact Form Submission';
        $mail->Body    = "Name: $name<br>Email: $email<br>Message: $message";

        // Send email
        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
